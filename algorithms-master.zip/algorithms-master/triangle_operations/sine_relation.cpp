#include <iostream>
#include <cmath>

using namespace std; 

int main() {
    float k1, k2, ba, a; 
    std::cout << "Enter the first edge: "; cin >> k1; 
    std::cout << "Enter the second edge: "; cin >> k2; 
    std::cout << "Enter the between angle (ba): "; cin >> ba;

    a = (k1 * k2  * sin(ba * M_PI/180)) / 2;

    std::cout << "Field of triangle : " << a <<endl;

    system("pause");
    return 0;
}