#include <iostream>
#include <cmath>

using namespace std; 

int main() {
    float a, b, ba, c; 
    std::cout << "Enter the first edge: "; cin >> a; 
    std::cout << "Enter the second edge: "; cin >> b; 
    std::cout << "Enter the between angle (ba): "; cin >> ba;

    c = pow(pow(a,2) + pow(b,2) - 2*(a * b * cos(ba * M_PI/180)), 0.5);

    std::cout << "Field of triangle : " << c <<endl;

    system("pause");
    return 0;
}