#include <iostream>
#include <cmath>

using namespace std; 

int main() {
    float d, r, g; 
    std::cout << "Enter the angle (d): "; cin >> d; 
    r = (d * M_PI) / 180; 
    g = (d * 200) / 180;

    std::cout << "Radian : " << r << endl;
    std::cout << "Gradient : " << g << endl;

    system("pause");
    return 0;
}