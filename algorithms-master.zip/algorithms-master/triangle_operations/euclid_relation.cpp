#include <iostream>
#include <cmath>

using namespace std; 

int main() {
    float p, k, h, c, b; 
    
    std::cout << "Enter the p edge: "; cin >> p; 
    std::cout << "Enter the k edge: "; cin >> k; 
    
    h = pow((p*k),0.5);
    b = pow(k*(p+k), 0.5);
    c = pow(p*(p+k), 0.5);

    std::cout << "Height of triangle : " << h <<endl;
    std::cout << "Height of b : " << b <<endl;
    std::cout << "Height of c : " << h <<endl;

    system("pause");
    return 0;
}