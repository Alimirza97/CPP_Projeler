#include <iostream>
#include <cmath>

using namespace std; 

int main() {
    float a, k, h; 
    std::cout << "Enter the edge length (cm) : "; cin >> k; 
    std::cout << "Enter the height (cm): "; cin >> h;
    a = (k * h)/2;
    std::cout << "\nField of triangle: (cm^2): " << a << endl;  
    system("pause"); 
    return 0;
}