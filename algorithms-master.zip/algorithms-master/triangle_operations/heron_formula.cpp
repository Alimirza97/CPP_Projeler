#include <iostream>
#include <cmath>

using namespace std; 

int main() {
    float a, b, u, c, field;
    
    std::cout << "Enter the first edge : "; cin >> a; 
    std::cout << "Enter the second edge : "; cin >> b; 
    std::cout << "Enter the third edge : "; cin >> c; 
    
    u = (a + b + c)/2; 
    field = pow(u*(u-a)*(u-b)*(u-c), 0.5); 

    std::cout << "Field of triangle : " << field <<endl;

    system("pause");
    return 0;
}