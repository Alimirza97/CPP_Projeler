#include <iostream>
#include <cmath>

using namespace std; 


int main() {
    float m, ma, mol;

    std::cout << "Enter the mass of the object : "; cin >> m;
    std::cout << "Enter the molecular weight of the object : "; cin >> ma;
    
    mol = (m/ma);
    
    std::cout << "Mol count of the object : " << mol <<endl;
   
    system("pause");
    return 0;
}