#include <iostream>
#include <cmath>

using namespace std; 


int main() {
    float v, i, r;

    std::cout << "Enter the resistance of the conductive : "; cin >> r;
    std::cout << "Enter the translucent current of the conductive : "; cin >> i;
    
    v = (i*r);
    
    std::cout << "v of the conductive: " << v <<endl;
   
    system("pause");
    return 0;
}