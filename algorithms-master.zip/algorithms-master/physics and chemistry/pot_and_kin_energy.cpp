#include <iostream>
#include <cmath>

using namespace std; 



int main() {
    float m, v, h, ep, ek; 
    
    std::cout << "Enter the mass of the substance (m) : "; cin >> m; 
    std::cout << "Enter the momentum of the substance (v) : "; cin >> v;
    std::cout << "Enter the ground clearance of the substance (h) : "; cin >> h;
    
    //ep = mgh
    ep = m*9.8*h;
    //ek = 0.5*m*v^2
    ek = 0.5*(m*pow(v,2));

    std::cout << "Potantial energy of substance : " << ep <<endl;
    std::cout << "Kinetic energy of substance : " << ek <<endl;

    system("pause");
    return 0;
}