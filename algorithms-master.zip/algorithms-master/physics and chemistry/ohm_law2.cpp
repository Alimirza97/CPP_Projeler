#include <iostream>
#include <cmath>

using namespace std; 


int main() {
    float e, r1, r2, r3, r4, i, vr1, pr2;

    std::cout << "Enter the voltage of the circuit : "; cin >> e;
    std::cout << "Enter the R1 of the circuit : "; cin >> r1;
    std::cout << "Enter the R2 of the circuit : "; cin >> r2;
    std::cout << "Enter the R3 of the circuit : "; cin >> r3;
    std::cout << "Enter the R4 of the circuit : "; cin >> r4;
    
    i = e/(r1+r2+r3+r4);
    vr1 = i*r1;
    pr2 = i*i * r2;
    
    std::cout << "i : " << i <<endl;
    std::cout << "vr1 : " << vr1 <<endl;
    std::cout << "pr2 : " << pr2 <<endl;
   
    system("pause");
    return 0;
}