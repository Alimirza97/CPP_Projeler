#include <iostream>
#include <cmath>

using namespace std; 


int main() {
    float h, v0, t, v, x, vx, vy; 
    
    std::cout << "Enter the ground clearance of the object (h) : "; cin >> h;
    std::cout << "Enter the first momentum of the object (v0) : "; cin >> v0;
    
   //h = 0*5*g*t^2 --> t = sqrt(2*h/g)
    t = sqrt(2*h/9.8);
    // x = v0*t 
    x = v0 * t;

   // vx = v0 and vy = g*t --> v = vx^2 * vy^2
    vx = v0;
    vy = 9.8*t;
    
    v = sqrt(pow(vx, 2)*pow(vy, 2));

    std::cout << "Endurance of the object : " << t <<endl;
    std::cout << "Intake on the path of the object : " << x <<endl;
    std::cout << "Hit the ground momentum of the object : " << v <<endl;

    system("pause");
    return 0;
}